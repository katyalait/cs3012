
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.1.0'
version = '1.1.0'
full_version = '1.1.0'
git_revision = '14142ff70d84a6ce74044a27919c850e893648f7'
release = True

if not release:
    version = full_version
